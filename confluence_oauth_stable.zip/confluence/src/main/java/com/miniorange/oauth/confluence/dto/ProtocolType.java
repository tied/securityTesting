package com.miniorange.oauth.confluence.dto;

public enum ProtocolType {
    OAUTH,

    OPENID
}
